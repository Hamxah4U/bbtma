<?php
session_start();

$uri = parse_url($_SERVER['REQUEST_URI'])['path'];

if (!isset($_SESSION['userID']) && $uri != '/' && $uri != '/login' && $uri != '/') {
   header('Location: /');
   exit();
}

$routes = [
    '/' => 'controllers/index.php', 
    '/about' => 'controllers/about.php',
    '/contact' => 'controllers/contact.php'
];

if(array_key_exists($uri, $routes)){
    require $routes[$uri];
}else{
    require 'controllers/404.php';
}